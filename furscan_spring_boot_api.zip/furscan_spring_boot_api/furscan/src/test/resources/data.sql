INSERT INTO mst_users
(user_id,
 email,
 first_name,
 is_active,
 is_doctor,
 last_name,
 otp,
 password,
 phone_no)
VALUES
    ('101',
     'samit@g.com',
     'samit doc',
     1,
     1,
     'doc',
     123456,
     '12345',
     '123456789');
