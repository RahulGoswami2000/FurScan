package furscan.furscan.Service;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;

import furscan.furscan.Services.UserService;

public class UserServiceTest {

     @InjectMocks
     UserService userService;

     @BeforeEach
     public void init() {

     }
     
}
